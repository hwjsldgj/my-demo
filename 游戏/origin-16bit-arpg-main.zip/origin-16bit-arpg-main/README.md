# 起源（Origin）

[中文](#中文) · [English](#english)

## 中文

《起源》是一款可直接在浏览器中游玩的 2D 16-bit 像素风动作角色扮演游戏原型，玩法设计参考《Chronicon》。项目由 Fable5 根据自然语言提示生成，并经过人工整理、测试与问题修复。

游戏以单个 HTML 文件运行，不需要安装依赖或执行构建命令。游戏引擎、像素美术、界面和合成音频均包含在页面中。

### 在线体验

GitHub Pages：<https://dfarm6.github.io/origin-16bit-arpg/>

也可以下载项目后直接打开 `index.html`。如果浏览器限制本地页面功能，可在项目目录启动静态服务器：

```bash
python3 -m http.server 8000
```

随后访问 <http://localhost:8000>。

### 游戏内容

- 战士、法师和游侠三种职业
- 移动、冲刺、碰撞与实时战斗系统
- 技能、技能树和技能特效
- 装备、战利品、药水与物品稀有度系统
- 商店、铁匠、仓库、悬赏和角色成长系统
- 多种普通敌人、精英敌人和 Boss
- 翡翠镇以及多个不同环境的冒险区域
- 昼夜变化、动态 NPC、粒子效果和小地图
- 程序化像素美术与浏览器合成音频
- 本地角色和游戏进度存储（取决于运行环境支持）

### 操作方式

| 操作 | 按键 |
| --- | --- |
| 移动 | `WASD` 或方向键 |
| 技能位 1 | 鼠标左键 |
| 技能位 2 | 鼠标右键 |
| 技能位 3 | `Q` |
| 技能位 4／互动 | `E` |
| 冲刺 | 空格键 |
| 使用生命药水 | `1` |
| 使用法力药水 | `2` |
| 打开技能树 | `K` |

游戏同时提供触屏操作支持。

### 项目结构

```text
.
├── index.html   # 完整游戏及其全部代码和内置素材
├── README.md    # 中英文项目说明
└── LICENSE      # MIT 开源许可证
```

### 原始提示词

本项目使用 Fable5 制作，整理后的提示词如下：

> 构建一款完整、可玩的 2D 16-bit 像素风 MMORPG 游戏，名称叫《起源》。
>
> 机制：游戏玩法类似《Chronicon》。
>
> 技术栈：可直接在浏览器中游玩。
>
> 构建内容：完整游戏引擎、物理系统、碰撞系统、游戏循环、技能特效、所有游戏机制、UI、菜单、音频、战斗系统、战利品系统、商店、升级系统、多种敌人类型和 Boss、具有动态世界的城镇广场、从零开始制作的动画，以及不同环境的冒险地图。
>
> 验证要求：游戏可以启动、可以正常游玩，并通过端到端测试。
>
> 请自主完成全部工作，完成后向我汇报。所有游戏素材应使用网上免费开源的素材或由 AI 生成，避免生硬拼凑样式。

### 测试与说明

项目已检查 JavaScript 语法，并验证三种职业均可完成“选择职业 → 进入翡翠镇”的场景切换。此前进入翡翠镇后出现黑屏，是因为低分辨率世界缓冲画布没有合成到主画布；当前版本已经修复。

这是一个由 AI 辅助生成的游戏原型。发布正式版本前，建议继续进行不同浏览器、触屏设备、完整流程和存档兼容性测试。

### 素材与许可证

当前页面中的像素图形主要由代码程序化生成，音频由浏览器端代码实时合成，项目不依赖外部图片、字体或音频文件。若后续加入第三方素材，请列出素材名称、作者、来源链接和许可证，并确认许可证允许再分发。

本项目采用 [MIT License](LICENSE) 开源许可证。

本项目仅参考《Chronicon》的玩法类型。《Chronicon》的名称、商标及其原始美术、音频和其他资产均属于各自权利人，本项目不包含或授权使用这些资产。

### 作者

- X：[@DFarm_club](https://x.com/DFarm_club)
- GitHub：[@DFarm6](https://github.com/DFarm6)
- 项目构建工具：Fable5

---

## English

**Origin** is a playable browser-based 2D 16-bit pixel action RPG prototype inspired by the gameplay style of *Chronicon*. It was generated with Fable5 from a natural-language prompt and subsequently refined, tested, and debugged.

The game runs from a single HTML file with no dependencies or build step. Its game engine, pixel graphics, interface, and synthesized audio are all contained in the page.

### Play Online

GitHub Pages: <https://dfarm6.github.io/origin-16bit-arpg/>

You can also download the project and open `index.html` directly. If your browser restricts local-page features, start a static server from the project directory:

```bash
python3 -m http.server 8000
```

Then visit <http://localhost:8000>.

### Features

- Three playable classes: Warrior, Mage, and Ranger
- Movement, dashing, collision, and real-time combat
- Skills, skill trees, and visual skill effects
- Equipment, loot, potions, and item rarity
- Shops, blacksmithing, storage, bounties, and character progression
- Multiple regular enemies, elite enemies, and bosses
- Emerald Town and several adventure zones with distinct environments
- Day/night changes, dynamic NPCs, particles, and a minimap
- Procedurally generated pixel graphics and browser-synthesized audio
- Local character and progress storage when supported by the runtime

### Controls

| Action | Control |
| --- | --- |
| Move | `WASD` or arrow keys |
| Skill slot 1 | Left mouse button |
| Skill slot 2 | Right mouse button |
| Skill slot 3 | `Q` |
| Skill slot 4 / Interact | `E` |
| Dash | Space |
| Use health potion | `1` |
| Use mana potion | `2` |
| Open skill tree | `K` |

Touch controls are also supported.

### Project Structure

```text
.
├── index.html   # Complete game, source code, and embedded assets
├── README.md    # Chinese and English documentation
└── LICENSE      # MIT License
```

### Original Prompt

This project was created with Fable5. The original prompt, translated into English, was:

> Build a complete and playable 2D 16-bit pixel-art MMORPG named **Origin**.
>
> Mechanics: The gameplay should be similar to *Chronicon*.
>
> Technology: It must be playable directly in a web browser.
>
> Build a complete game engine, physics system, collision system, game loop, skill effects, all gameplay mechanics, UI, menus, audio, combat, loot, shops, progression, multiple enemy types and bosses, a lively town square with a dynamic world, original animation, and adventure maps with different environments.
>
> Verification: The game must launch, be playable, and pass end-to-end testing.
>
> Complete the work autonomously and report back when finished. Use freely licensed online assets or AI-generated game assets, and avoid visually forced or poorly matched styling.

### Testing and Notes

The JavaScript syntax has been checked, and all three classes have been verified through the “select a class → enter Emerald Town” transition. A previous black-screen issue was caused by the low-resolution world buffer not being composited onto the main canvas; this version includes the fix.

This is an AI-assisted game prototype. Additional testing across browsers, touch devices, full game progression, and save-data compatibility is recommended before a production release.

### Assets and License

The page primarily uses pixel graphics generated procedurally in code and audio synthesized in the browser. It does not depend on external image, font, or audio files. Any third-party assets added later should include their title, author, source URL, and license, with redistribution rights verified.

This project is released under the [MIT License](LICENSE).

This project is inspired only by the gameplay style of *Chronicon*. The *Chronicon* name, trademarks, original art, audio, and other assets belong to their respective owners and are not included or licensed by this project.

### Author

- X: [@DFarm_club](https://x.com/DFarm_club)
- GitHub: [@DFarm6](https://github.com/DFarm6)
- Project generation tool: Fable5
